//============================================================================
// Name        : I2C.cpp
// Author      : Kacper Potoczny
// Version     : Ver0.1
// Date        : 09.09.2018
// Copyright   : FG002/Future Gadget Lab
// Description : Library to simplify I2C communication
//============================================================================

//#include <stdint.h>
//#include <stdlib.h>
//#include <stdio.h>
#include <unistd.h>
#include <linux/i2c-dev.h>
//#include <sys/types.h>
//#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <iostream>
#include "I2C.hpp"

// I2C Linux device handle
int g_i2cFile;

// open the Linux device
void i2cOpen()
{
	g_i2cFile = open("/dev/i2c-1", O_RDWR);
	if (g_i2cFile < 0)
	{
		perror("i2cOpen");
		exit(1);
	}
}

// close the Linux device
void i2cClose()
{
	close(g_i2cFile);
}

// set the I2C slave address for all subsequent I2C device transfers
void i2cSetAddress(uint8_t address)
{
	if (ioctl(g_i2cFile, I2C_SLAVE, address) < 0)
	{
		perror("i2cSetAddress");
		exit(1);
	}
}

// Write *samples of *data to *cell
void i2cWrite(uint8_t cell,uint8_t data)
{

	uint8_t reg[2] = {cell,data};
	if (write(g_i2cFile, reg, 2) != 2) {
		perror("i2cSetcell");
	}
	//if (write(g_i2cFile, data, samples) != samples) {
	//	perror("i2cSetRegister");
	//}
}

// Read *samples of *data from *cell
uint8_t i2cRead(uint8_t cell)
{
	uint8_t reg[1] = {cell};
	uint8_t data[1];
	if (write(g_i2cFile, reg, 1) != 1) {
		perror("i2c set cell");
	}
	if (read(g_i2cFile, data, 1) != 1) {
		perror("i2c read value");
}
	return data[0];
}

//Write 24 registers to PCA9685
void i2cWrite24(uint8_t cell,uint8_t data[6][4])
{
	uint8_t reg[25];
	reg[0]=cell;
	for(uint8_t i=0;i>6;)
	{
		reg[1*i+0]=data[i][0];
		reg[1*i+1]=data[i][1];
		reg[1*i+2]=data[i][2];
		reg[1*i+3]=data[i][3];
		i++;
	}

	if (write(g_i2cFile, reg, 25) != 25)
	{
		perror("i2c24Setcell");
	}
}



