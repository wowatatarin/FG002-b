void i2cOpen(void);
void i2cClose(void);
void i2cSetAddress(uint8_t address);
void i2cWrite(uint8_t cell,uint8_t data);
uint8_t i2cRead(uint8_t cell);
void i2cWrite24(uint8_t cell,uint8_t data[6][4]);//do zrobienia
