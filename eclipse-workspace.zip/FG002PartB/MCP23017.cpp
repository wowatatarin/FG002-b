#include "MCP23017.hpp"

void MCP23017::init()
{
	i2cSetAddress(Address);
	i2cWrite(IODIRA,0x00);
}
void MCP23017::write()
{
	i2cSetAddress(Address);
	i2cWrite(OLATA,direction);
}
