#include <stdint.h>
#include <stdlib.h>
#include <iostream>
#include "I2C.hpp"
//gpio ports A
#define IODIRA		0x00	// 0 = Output 1 = Input			<
#define IPOLA		0x02	// 1 = logic inverted
#define GPINTENA	0x04	// 1 = interrupt is on
#define GPPUA		0x0C	// Pullup resistors
#define GPIOA		0x12	// General purpose register
#define OLATA		0x14	// Output latch register		<
//control registers A
#define DEFVALA		0x06	// default value?
#define INTCONA		0x08	// INTERRUPT CONTROLL
#define INTFA		0x0E	// Interrupt flag
#define INTCAPA		0x10	// Interrupt captured value

#define Address		0x20

class MCP23017
{
public:
	uint8_t direction;
	void init();
	void write();
};
