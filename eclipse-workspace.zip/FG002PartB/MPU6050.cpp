//============================================================================
// Name        : MPU6050.cpp
// Author      : Kacper
// Version     : Ver0.1
// Copyright   : Future Gadget Lab
// Description : Universal library to control MPU6050
//============================================================================
#include <stdio.h>
#include "MPU6050.h"
#include "I2C.hpp"

//accel addresses
#define  AccXh         0x3B   // R
#define  AccXl         0x3C   // R
#define  AccYh         0x3D   // R
#define  AccYl         0x3E   // R
#define  AccZh         0x3F   // R
#define  AccZl         0x40   // R
//gyro addresses
#define  GyrXh         0x43   // R
#define  GyrXl         0x44   // R
#define  GyrYh         0x45   // R
#define  GyrYl         0x46   // R
#define  GyrZh         0x47   // R
#define  GyrZl         0x48   // R
//temp addresses
#define  TempH         0x41   // R
#define  TempL         0x42   // R
//MPU6050 manage
#define PWR_MGMT_1     0x6B   // R/W
#define PWR_MGMT_value     0x20   // R/W



//uruchomienie MCU6050
void MPU6050::init()
{
	i2cSetAddress(MPUaddress);
	i2cWrite(PWR_MGMT_1,PWR_MGMT_value);
}

//odczyt akcelerometru
void MPU6050::readAccel()
{
	i2cSetAddress(MPUaddress);
	accel[0] = i2cRead(AccXh)<<8 | i2cRead(AccXl);
	accel[1] = i2cRead(AccYh)<<8 | i2cRead(AccYl);
	accel[2] = i2cRead(AccZh)<<8 | i2cRead(AccZl);
}

//odczyt żyroskopu
void MPU6050::readGyro()
{
	i2cSetAddress(MPUaddress);
	gyro[0] = i2cRead(GyrXh)<<8 | i2cRead(GyrXl);
	gyro[1] = i2cRead(GyrYh)<<8 | i2cRead(GyrYl);
	gyro[2] = i2cRead(GyrZh)<<8 | i2cRead(GyrZl);
}

//odczyt temperatury
void MPU6050::readTemp()
{
	i2cSetAddress(MPUaddress);
	temp = i2cRead(TempH)<<8 | i2cRead(TempL);
	 //C = (TEMP_OUT Register Value as a signed quantity)/340 + 36.53
	temperature = temp/340.0 + 36.53;
}

