#include <stdint.h>
#include <stdlib.h>
#include <iostream>

//device address
#define MPUaddress  0x68

class MPU6050
{
public:
	int16_t gyro[3];
	int16_t accel[3];
	int16_t temp;
	float temperature;

	void init();
	void readAccel();
	void readGyro();
	void readTemp();
};
