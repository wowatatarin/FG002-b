#include <stdint.h>
#include <stdlib.h>
#include <iostream>
#include "I2C.hpp"
#include "PCA9685.hpp"


void PCA9685::init()
{
	i2cSetAddress(PCA9685address);
	i2cWrite(Mode1,0x01);
	i2cWrite(All_Led_on_h,0x00);
	i2cWrite(All_Led_on_l,0x00);
	i2cWrite(All_Led_off_h,0x00);
	i2cWrite(All_Led_off_l,0x00);
}
void PCA9685::writePWM()
{
	i2cSetAddress(PCA9685address);
	for(uint8_t i=0;i<6;)
	{
		uint16_t PWMcalc = PWM[i]*4;
		Led[i][0]=!PWMcalc;
		Led[i][1]=!PWMcalc>>8;
		Led[i][2]=PWMcalc+2047;
		Led[i][3]=(PWMcalc>>8)+2047;
		i2cWrite24(Led0_on_l,Led);
		i++;
	}
}
void PCA9685::error()
{
	i2cSetAddress(PCA9685address);
	//i2cWrite(All_Led_on_h,0x00);
	i2cWrite(All_Led_off_h,0x10);//trzeba sprzwdzić
}
