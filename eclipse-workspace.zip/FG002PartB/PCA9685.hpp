
#include <stdint.h>
#include <stdlib.h>
#include <iostream>

#define PCA9685address   0x70

#define AllCallAddr		 0x05

#define Mode1 			 0x00
#define Mode2 			 0x01

#define Led0_on_l		 0x06
#define Led0_on_h		 0x07
#define Led0_off_l		 0x08
#define Led0_off_h		 0x09

#define Led1_on_l		 0x0A
#define Led1_on_h		 0x0B
#define Led1_off_l		 0x0C
#define Led1_off_h		 0x0D

#define Led2_on_l		 0x0E
#define Led2_on_h		 0x0F
#define Led2_off_l		 0x10
#define Led2_off_h		 0x11

#define Led3_on_l		 0x12
#define Led3_on_h		 0x13
#define Led3_off_l		 0x14
#define Led3_off_h		 0x15

#define Led4_on_l		 0x16
#define Led4_on_h		 0x17
#define Led4_off_l		 0x18
#define Led4_off_h		 0x19

#define Led5_on_l		 0x1A
#define Led5_on_h		 0x1B
#define Led5_off_l		 0x1C
#define Led5_off_h		 0x1D

#define All_Led_on_l	 0xFA
#define All_Led_on_h	 0xFB
#define All_Led_off_l	 0xFC
#define All_Led_off_h	 0xFD


class PCA9685
{
public:
	uint8_t PWM[6];
	uint8_t Led[6][4];

public:
	void init();
	void writePWM();
	void error();

};
