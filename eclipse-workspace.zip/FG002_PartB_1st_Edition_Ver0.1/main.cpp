#include <stdint.h>
#include <stdlib.h>
//#include <cstdio>
#include <unistd.h>
//#include <sys/types.h>
//#include <sys/stat.h>
//#include <sys/ioctl.h>
//#include <fcntl.h>
//#include <iostream>
#include "I2C.hpp"
#include "MPU6050.h"
#include "PCA9685.hpp"
#include "MCP23017.hpp"


//int argc, char** argv
int main()
{
	std::cout<<"dupa";
	i2cOpen();
	printf("dupa");
	PCA9685 dev2;
	printf("dupa");
	dev2.init();
	printf("dupa");
	//MCP23017 dev3;
	//dev3.init();
	for(uint8_t i = 0;i<6;i++)
	{
		printf("dupa");
		dev2.PWM[i]=255;
		dev2.writePWM();
		printf("%d",i);
		sleep(1000);
	}
	dev2.init();
	i2cClose();
	return 0;
}
/*void komenda()
{
	if(;kom[1]=F;kom[1]=0)
	else if(;kom[1]=B;kom[1]=0)
	else if(;kom[1]=L;kom[1]=0)
	else if(;kom[1]=R;kom[1]=0)
	else if(;kom[1]=S;kom[1]=0)
}*/



